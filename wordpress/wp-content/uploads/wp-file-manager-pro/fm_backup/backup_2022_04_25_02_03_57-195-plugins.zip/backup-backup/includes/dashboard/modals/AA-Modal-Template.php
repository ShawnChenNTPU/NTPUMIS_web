<?php

  // Namespace
  namespace BMI\Plugin\Dashboard;

  // Exit on direct access
  if (!defined('ABSPATH')) exit;

?>

<a href="#" class="modal-opener" data-modal="test-modal">Open test modal</a>

<div class="modal" id="test-modal">

  <div class="modal-wrapper" style="max-width: 564px; max-width: min(564px, 80vw);">
    <a href="#" class="modal-close">×</a>
    <div class="modal-content">

      <div class="mm60 f26 medium">We noticed:</div>


    </div>
  </div>

</div>
